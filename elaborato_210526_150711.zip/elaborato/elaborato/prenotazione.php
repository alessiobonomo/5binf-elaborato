<?php
  require_once "config.php"; // Include del file di configurazione
  session_start(); /* Starts the session */

  if($_SESSION['Active'] == false)
  { /* Redirects user to Login.php if not logged in */
    header("location:login.php");
	exit;
  }
  $rows = getAllFeedback();
?>

<!-- Inserire sotto i contenuti protetti da password -->

<!DOCTYPE html>
<html>
  <head>
    <title>Logged in</title>
  </head>
  <body>
    <h2>Elenco dei visitatori che hanno fatto un feedback su poi con voto minore di 6</h2> 
    <ol>
        <?php foreach ($rows as $row): ?>
            <li><?php echo htmlspecialchars($row["nome_visitatore"]), " ", htmlspecialchars($row["cognome"]) ?></li>
        <?php endforeach; ?>
    </ol>
    <p><a href="index.php">Vai indietro</a></p>
  </body>
</html>
