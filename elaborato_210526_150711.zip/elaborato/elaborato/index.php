<?php
  session_start(); /* Starts the session */

  if($_SESSION['Active'] == false)
  { /* Redirects user to Login.php if not logged in */
	header("location:login.php");
	exit;
  }
?>

<!-- Inserire sotto i contenuti proteti da password -->

<!DOCTYPE html>
<html>
  <head>
    <title>Benvenuto</title>
  </head>
  <body>
    <h1>Benvenuto <?php echo $_SESSION['Username']?> </h1>
    <ul>
        <li>prenotazione</li>
		<li>test2</li>
    </ul>
    <a href="logout.php">Logout</a>
  </body>
</html>
